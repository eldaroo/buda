Jobhunt - WordPress Job Board Theme

The theme's documentation and the customer support are provided online. Here are a few useful links on getting started with the theme.

1. Theme Documentation - https://docs.madrasthemes.com/jobhunt/
2. Support - https://themeforest.net/item/jobhunt-job-board-wordpress-theme-for-wp-job-manager/22563674/support
3. Getting Started with WP Job Manager - https://wpjobmanager.com/documentation/
4. Getting Started with Wordpress - https://codex.wordpress.org/Getting_Started_with_WordPress
5. Installation Videos - https://www.youtube.com/channel/UChl9_bo48SEcl5O0ztc8Scw