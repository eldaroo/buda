<?php
$header_version = jobhunt_get_header_version();

get_header( $header_version ); ?>
