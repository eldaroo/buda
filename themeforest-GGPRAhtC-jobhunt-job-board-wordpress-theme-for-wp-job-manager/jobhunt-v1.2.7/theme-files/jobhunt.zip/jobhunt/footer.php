<?php
$footer_version = jobhunt_get_footer_version();

get_footer( $footer_version ); ?>