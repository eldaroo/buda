Jobhunt
==============================
Jobhunt is a WordPress Job Board Theme.

It features deep integration with WP Job Manager core plus several of the most popular extensions:

King Composer
Slider Revolution

The codebase of Jobhunt is lean and extensible which will allow develoepers to easily add functionality to your site via child theme and/or custom plugin(s).

Jobhunt Documentation
==============================
You can view detailed Jobhunt documentation on the Jobhunt documentation web site.

Jobhunt help & support
==============================
MadrasThemes customers can get support at the Madras Themes support portal.