<?php
/**
 * Jobhunt template functions.
 *
 * @package jobhunt
 */

require_once get_template_directory() . '/inc/template-functions/posts.php';
require_once get_template_directory() . '/inc/template-functions/single-post.php';
require_once get_template_directory() . '/inc/template-functions/pages.php';
require_once get_template_directory() . '/inc/template-functions/widgets.php';
require_once get_template_directory() . '/inc/template-functions/header.php';
require_once get_template_directory() . '/inc/template-functions/footer.php';
require_once get_template_directory() . '/inc/template-functions/homepage.php';