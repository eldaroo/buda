<?php
/**
 * Jetpack functions
 */