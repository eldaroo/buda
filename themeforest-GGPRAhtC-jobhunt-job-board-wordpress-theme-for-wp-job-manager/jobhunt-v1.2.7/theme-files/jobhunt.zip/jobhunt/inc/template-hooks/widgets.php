<?php

add_filter( 'widget_pages_args', 'jobhunt_modify_widget_pages_args', 10, 2 );
add_filter( 'widget_categories_args', 'jobhunt_modify_widget_categories_args', 10, 2 );
add_filter( 'widget_nav_menu_args', 'jobhunt_modify_widget_nav_menu_args', 10, 4 );
